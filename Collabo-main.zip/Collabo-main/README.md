# Collabo
<h2>Team Details</h2>
<b>Team Number: </b><p>24AACR23</p>
<b>Junior Mentor:</b><p> B Vaishnavi , Sai Teja Reddy</p>
<b>Team Member 1:</b><p> Nagarjunapu Sri Vedha Samhitha</p>
<b>Team Member 2:</b><p> Patha Sanjana</p>
<b>Team Member 3:</b><p> Naraharisetti Naga Sai Nikhil</p>
<b>Team Member 4:</b><p> Sreyas Rao</p>
<b>Team Member 5:</b><p> Katukuri Praneeth Reddy</p>

